
import React from 'react';
import { Member } from '../types';

const MOCK_MEMBERS: Member[] = [
  { id: '1', name: '爸爸', avatar: 'https://i.pravatar.cc/150?u=papa', role: '團長 / 司機' },
  { id: '2', name: '媽媽', avatar: 'https://i.pravatar.cc/150?u=mama', role: '美食採購 / 攝影' },
  { id: '3', name: '姊姊', avatar: 'https://i.pravatar.cc/150?u=sister', role: '翻譯 / 導覽' },
  { id: '4', name: '我', avatar: 'https://i.pravatar.cc/150?u=me', role: '技術支援' },
];

const MembersView: React.FC = () => {
  const tripUrl = window.location.href;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: '奶茶旅行 - 我們的東京之旅',
          text: '快來加入我們的行程規劃，大家一起編輯同步吧！',
          url: tripUrl,
        });
      } catch (err) {
        console.log('取消分享');
      }
    } else {
      navigator.clipboard.writeText(tripUrl);
      alert('已複製網址，請發送給家人！');
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="text-center py-10 bg-white rounded-[48px] shadow-xl border border-milktea-200 relative overflow-hidden">
        <div className="relative z-10">
          <div className="w-24 h-24 bg-theme-main rounded-full mx-auto mb-6 border-4 border-white shadow-lg p-1 overflow-hidden">
            <img src="https://picsum.photos/seed/japan/200/200" alt="Group" className="w-full h-full object-cover rounded-full" />
          </div>
          <h3 className="text-2xl font-black font-elegant text-theme-text">我們的東京暴飲暴食團</h3>
          <p className="text-sm text-theme-main/60 mt-2 font-black uppercase tracking-widest">Family Sync Active</p>
        </div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-theme-main/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
      </div>

      <div className="space-y-4">
        <h4 className="text-xs font-black text-theme-main/40 px-2 uppercase tracking-[0.3em]">同步中的成員</h4>
        {MOCK_MEMBERS.map((member) => (
          <div key={member.id} className="bg-white rounded-[32px] p-5 flex items-center justify-between border border-white shadow-sm active:bg-theme-light/50 transition-all">
            <div className="flex items-center gap-4">
              <img src={member.avatar} alt={member.name} className="w-14 h-14 rounded-2xl object-cover shadow-inner" />
              <div>
                <h5 className="text-base font-black text-theme-text">{member.name}</h5>
                <p className="text-[10px] font-black text-theme-main/60 uppercase tracking-widest">{member.role}</p>
              </div>
            </div>
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
          </div>
        ))}
      </div>

      <div className="bg-theme-text text-white rounded-[40px] p-8 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 text-center">
          <i className="fa-solid fa-share-nodes text-3xl mb-4"></i>
          <h5 className="text-xl font-black mb-2">分享給家人同步</h5>
          <p className="text-[10px] opacity-60 mb-6 font-black uppercase tracking-widest">Invite family to collaborate</p>
          <button 
            onClick={handleShare}
            className="w-full bg-theme-main py-4 rounded-2xl font-black text-sm active:scale-95 transition-all shadow-xl"
          >
            發送邀請連結
          </button>
        </div>
        <i className="fa-solid fa-users absolute -right-4 -bottom-4 text-8xl opacity-10 rotate-12"></i>
      </div>
    </div>
  );
};

export default MembersView;
