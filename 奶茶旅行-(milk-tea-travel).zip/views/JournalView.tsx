
import React, { useState } from 'react';

interface Comment {
  id: string;
  author: string;
  text: string;
  time: string;
}

interface Post {
  id: string;
  author: string;
  avatar: string;
  location: string;
  image: string;
  caption: string;
  likes: number;
  comments: Comment[];
  time: string;
}

const MOCK_POSTS: Post[] = [
  {
    id: '1',
    author: 'Wei',
    avatar: 'https://i.pravatar.cc/150?u=wei',
    location: 'Shibuya Crossing',
    image: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=800&q=80',
    caption: '終於抵達澀谷了！這個人潮真的不是開玩笑的 🏃‍♂️💨',
    likes: 12,
    time: '2 小時前',
    comments: [
      { id: 'c1', author: 'Lin', text: '等等我也要在那邊拍一張！', time: '1 小時前' },
      { id: 'c2', author: 'Yuki', text: '快去買那家有名的可麗餅 🤤', time: '30 分鐘前' }
    ]
  },
  {
    id: '2',
    author: 'Lin',
    avatar: 'https://i.pravatar.cc/150?u=lin',
    location: 'Ichiran Ramen',
    image: 'https://images.unsplash.com/photo-1591814468924-caf88d1232e1?auto=format&fit=crop&w=800&q=80',
    caption: '半夜三點的一蘭，依舊是滿分 🍜✨',
    likes: 24,
    time: '5 小時前',
    comments: []
  }
];

const JournalView: React.FC = () => {
  const [posts, setPosts] = useState(MOCK_POSTS);
  const [newComment, setNewComment] = useState<Record<string, string>>({});

  const handleLike = (id: string) => {
    setPosts(posts.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p));
  };

  const addComment = (postId: string) => {
    if (!newComment[postId]) return;
    const comment: Comment = {
      id: Date.now().toString(),
      author: 'Me',
      text: newComment[postId],
      time: '剛才'
    };
    setPosts(posts.map(p => p.id === postId ? { ...p, comments: [...p.comments, comment] } : p));
    setNewComment({ ...newComment, [postId]: '' });
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      
      {/* 頂部發佈欄 */}
      <div className="bg-white rounded-[40px] p-6 shadow-sm border border-theme-main/10 flex items-center gap-5 active:scale-[0.98] transition-all">
        <div className="w-14 h-14 rounded-full bg-theme-main flex items-center justify-center text-white text-2xl shadow-lg shadow-theme-main/20">
          <i className="fa-solid fa-camera"></i>
        </div>
        <span className="text-theme-text/40 font-bold text-lg">分享今天的驚喜時刻...</span>
      </div>

      {/* 貼文流 */}
      <div className="space-y-12">
        {posts.map((post) => (
          <div key={post.id} className="bg-white rounded-[60px] overflow-hidden shadow-xl border border-theme-main/5 group">
            
            {/* 貼文頂部 */}
            <div className="p-8 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <img src={post.avatar} alt={post.author} className="w-12 h-12 rounded-full border-2 border-theme-main/20 p-0.5" />
                <div>
                  <h4 className="font-bold text-theme-text text-lg">{post.author}</h4>
                  <p className="text-[10px] text-theme-text/30 font-bold uppercase flex items-center gap-1">
                    <i className="fa-solid fa-location-dot"></i> {post.location}
                  </p>
                </div>
              </div>
              <button className="w-10 h-10 rounded-full bg-theme-light flex items-center justify-center text-theme-text/20">
                <i className="fa-solid fa-ellipsis"></i>
              </button>
            </div>

            {/* 貼文圖片 */}
            <div className="relative aspect-square overflow-hidden">
              <img src={post.image} alt="Post" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
            </div>

            {/* 互動按鈕 */}
            <div className="p-8 pb-0">
              <div className="flex gap-6 mb-6">
                <button 
                  onClick={() => handleLike(post.id)}
                  className="flex items-center gap-2 text-theme-text active:scale-125 transition-transform"
                >
                  <i className="fa-solid fa-heart text-2xl text-rose-500"></i>
                  <span className="font-bold text-lg">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-theme-text">
                  <i className="fa-regular fa-comment text-2xl"></i>
                  <span className="font-bold text-lg">{post.comments.length}</span>
                </button>
                <button className="ml-auto">
                  <i className="fa-regular fa-bookmark text-2xl text-theme-text/30"></i>
                </button>
              </div>

              {/* 標題敘述 */}
              <div className="space-y-2 mb-8">
                <p className="text-theme-text leading-relaxed">
                  <span className="font-bold mr-3">{post.author}</span>
                  {post.caption}
                </p>
                <p className="text-[10px] font-bold text-theme-text/30 uppercase tracking-widest">{post.time}</p>
              </div>

              {/* 留言列表 */}
              {post.comments.length > 0 && (
                <div className="space-y-4 pt-6 border-t border-theme-main/5 pb-6">
                  {post.comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <span className="font-bold text-sm text-theme-text min-w-[40px]">{comment.author}</span>
                      <p className="text-sm text-theme-text/70">{comment.text}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* 快速留言輸入 */}
              <div className="mt-2 flex gap-4 items-center border-t border-theme-main/10 py-6">
                <input 
                  type="text" 
                  placeholder="添加留言..." 
                  value={newComment[post.id] || ''}
                  onChange={(e) => setNewComment({ ...newComment, [post.id]: e.target.value })}
                  onKeyDown={(e) => e.key === 'Enter' && addComment(post.id)}
                  className="flex-1 bg-transparent outline-none text-sm font-bold text-theme-text"
                />
                <button 
                  onClick={() => addComment(post.id)}
                  className="text-theme-main font-bold text-sm disabled:opacity-30"
                  disabled={!newComment[post.id]}
                >
                  發佈
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default JournalView;
