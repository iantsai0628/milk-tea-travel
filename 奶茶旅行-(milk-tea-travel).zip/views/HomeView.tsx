
import React, { useState, useEffect } from 'react';
import { THEMES } from '../App';

type SubPageView = 'none' | 'vocab' | 'emergency' | 'culture';

interface HomeViewProps {
  onThemeChange: (idx: number) => void;
  currentThemeIdx: number;
}

const HomeView: React.FC<HomeViewProps> = ({ onThemeChange, currentThemeIdx }) => {
  const [subPage, setSubPage] = useState<SubPageView>('none');
  const [amountForeign, setAmountForeign] = useState<string>('10000');
  const [currency, setCurrency] = useState<'JPY' | 'KRW'>('JPY');
  const [activeSlide, setActiveSlide] = useState(0);
  const [showInstallTip, setShowInstallTip] = useState(true);

  const exchangeRates = { JPY: 0.215, KRW: 0.0245 };
  
  const highlights = [
    { title: '明治神宮', location: '澀谷區', time: '10:00', img: 'https://images.unsplash.com/photo-1590559899731-a382839e5549?auto=format&fit=crop&w=600&q=80', desc: '感受東京市中心的寧靜森林與宏偉鳥居。' },
    { title: '表參道逛街', location: '港區', time: '14:00', img: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=600&q=80', desc: '時尚尖端的地標，與獨具設計感的建築群。' },
    { title: 'SHIBUYA SKY', location: '澀谷車站', time: '17:30', img: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=600&q=80', desc: '在 229 公尺高空俯瞰璀璨的東京夜景。' }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % highlights.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [highlights.length]);

  const renderSubPageContent = () => {
    switch (subPage) {
      case 'vocab':
        return (
          <div className="space-y-8 pb-20 font-yuanwei">
            <h3 className="text-3xl font-black mb-8 flex items-center gap-3">
              <i className="fa-solid fa-language text-theme-main"></i> 極致旅遊語手帖
            </h3>
            <div className="grid gap-6">
              {[
                { cat: '生活必備', items: [
                  { jp: 'すみません', tw: '不好意思 (Sumimasen)', note: '點餐、搭話、道歉、借過。' },
                  { jp: 'これをお願いします', tw: '請給我這個 (Kore o onegaishimasu)', note: '指著圖片說這句最快速。' },
                  { jp: 'お会計をお願いします', tw: '請幫我結帳 (O-kaikei o onegaishimasu)', note: '用餐完畢時使用。' },
                  { jp: 'ありがとうございます', tw: '謝謝 (Arigatou gozaimasu)', note: '基本的禮貌核心。' }
                ]},
                { cat: '問路救援', items: [
                  { jp: 'トイレはどこですか？', tw: '廁所在哪？ (Toire wa doko desu ka?)', note: '救急必備。' },
                  { jp: 'Wi-Fiがありますか？', tw: '有 Wi-Fi 嗎？ (Wi-Fi ga arimasu ka?)', note: '詢問網路連線。' },
                  { jp: '免稅できますか？', tw: '可以免稅嗎？ (Menzei dekimasu ka?)', note: '藥妝購物省錢關鍵。' }
                ]},
                { cat: '美食點餐', items: [
                  { jp: 'おすすめは何ですか？', tw: '有推薦的嗎？ (Osusume wa nandesu ka?)', note: '不知道點什麼時用。' },
                  { jp: '美味しいです！', tw: '很好吃！ (Oishii desu!)', note: '給主廚最好的鼓勵。' }
                ]}
              ].map((group, idx) => (
                <div key={idx} className="space-y-4">
                  <h4 className="text-xs font-black text-theme-main uppercase tracking-[0.3em] px-2">{group.cat}</h4>
                  {group.items.map((v, i) => (
                    <div key={i} className="bg-white p-6 rounded-[32px] border border-theme-main/10 shadow-sm active:scale-[0.98] transition-all">
                      <p className="text-2xl font-black text-theme-main mb-1">{v.jp}</p>
                      <p className="text-sm font-black text-theme-text mb-2">{v.tw}</p>
                      <p className="text-[11px] text-theme-text/40">{v.note}</p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        );
      case 'emergency':
        return (
          <div className="space-y-8 pb-20 font-yuanwei">
            <h3 className="text-3xl font-black mb-8 flex items-center gap-3">
               <i className="fa-solid fa-life-ring text-rose-500"></i> 緊急應變手札
            </h3>
            <div className="bg-rose-50 p-8 rounded-[48px] border-2 border-rose-100 mb-6 shadow-inner">
              <p className="text-rose-500 text-[10px] font-black tracking-widest uppercase mb-2">Foreign Affairs</p>
              <h4 className="text-2xl font-black text-rose-700">台北駐日代表處</h4>
              <p className="text-sm text-rose-600 mt-2 font-bold leading-relaxed">
                24H急難救助：03-3280-7911<br/>
                領務申辦：03-3280-7811<br/>
                地址：東京都港區白金台5-20-2
              </p>
            </div>
            <div className="grid gap-4">
               {[
                 { title: '救急/火災', num: '119', note: '急救車輛需求時撥打。', icon: 'fa-ambulance' },
                 { title: '警察/報案', num: '110', note: '遺失物品、發生事故、失竊。', icon: 'fa-shield' },
                 { title: '信用卡掛失', num: '各銀行專線', note: '建議事先將卡片背面電話存檔。', icon: 'fa-credit-card' },
                 { title: '日本觀光局諮詢', num: '050-3816-2787', note: '24小時多國語言旅遊協助。', icon: 'fa-info-circle' }
               ].map((e, i) => (
                 <div key={i} className="bg-white p-7 rounded-[40px] border border-theme-main/10 flex justify-between items-center shadow-sm active:scale-95 transition-all">
                   <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-theme-light rounded-2xl flex items-center justify-center text-theme-main">
                        <i className={`fa-solid ${e.icon}`}></i>
                     </div>
                     <div>
                       <p className="font-black text-theme-text text-lg">{e.title}</p>
                       <p className="text-[11px] text-theme-text/40">{e.note}</p>
                     </div>
                   </div>
                   <p className="text-2xl font-black text-theme-main tracking-tighter">{e.num}</p>
                 </div>
               ))}
            </div>
          </div>
        );
      case 'culture':
        return (
          <div className="space-y-8 pb-20 font-yuanwei">
            <h3 className="text-3xl font-black mb-8">⚠️ 在地文化禮儀</h3>
            <div className="space-y-6">
              {[
                { title: '交通：安靜至上', desc: '電車內禁止講電話，且通常不進行大聲交談，手機務必轉為靜音。', icon: 'fa-train-subway' },
                { title: '餐飲：關於結帳', desc: '大部分傳統店家仍以現金為主，或是需到櫃檯出示桌號牌結帳，不流行在餐桌付錢。', icon: 'fa-wallet' },
                { title: '購物：垃圾處理', desc: '日本街頭極少垃圾桶，通常在超商門口或車站內。請自行準備垃圾袋回旅館處理。', icon: 'fa-trash-can' },
                { title: '禮貌：靠邊行進', desc: '東京電扶梯習慣靠左站立；大阪則相反。行進間請勿並排堵住通道。', icon: 'fa-person-walking' },
                { title: '購物：退稅須知', desc: '消費滿 5,000 日圓可享退稅，須出示護照正本，免稅品在離境前不可拆封。', icon: 'fa-passport' }
              ].map((c, i) => (
                <div key={i} className="bg-white p-8 rounded-[48px] border border-theme-main/5 shadow-md flex gap-6 items-start">
                  <div className="w-12 h-12 bg-theme-main/10 rounded-3xl flex items-center justify-center text-theme-main shrink-0">
                    <i className={`fa-solid ${c.icon}`}></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-black text-theme-text mb-2">{c.title}</h4>
                    <p className="text-sm text-theme-text/60 leading-relaxed font-bold">{c.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      default: return null;
    }
  };

  if (subPage !== 'none') {
    return (
      <div className="fixed inset-0 bg-theme-light z-[100] p-6 pt-16 overflow-y-auto animate-in slide-in-from-right duration-500">
        <button onClick={() => setSubPage('none')} className="mb-10 w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-all">
          <i className="fa-solid fa-arrow-left text-theme-text"></i>
        </button>
        {renderSubPageContent()}
      </div>
    );
  }

  const convertedTWD = (parseFloat(amountForeign) * (currency === 'JPY' ? exchangeRates.JPY : exchangeRates.KRW)).toFixed(0);

  return (
    <div className="space-y-8 animate-in fade-in duration-800 pb-10">
      
      {/* 0. PWA 安裝提示 (優雅卡片) */}
      {showInstallTip && (
        <section className="bg-theme-main/10 rounded-[40px] p-6 border border-theme-main/20 flex items-center gap-5 relative overflow-hidden animate-in slide-in-from-top duration-700">
          <div className="w-12 h-12 bg-theme-main rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg">
             <i className="fa-solid fa-mobile-screen-button"></i>
          </div>
          <div className="flex-1">
             <h5 className="text-xs font-black text-theme-text uppercase tracking-widest">將 App 加入桌面</h5>
             <p className="text-[10px] text-theme-text/60 font-bold leading-tight mt-1">點擊分享選單並選擇「加入主畫面」，體驗極致流暢！</p>
          </div>
          <button onClick={() => setShowInstallTip(false)} className="text-theme-text/20 p-2"><i className="fa-solid fa-xmark"></i></button>
        </section>
      )}

      {/* 1. 主題切換器 (8色) */}
      <section className="bg-white/40 backdrop-blur-md rounded-[40px] p-6 shadow-sm border border-white/50">
        <p className="text-[10px] font-black text-theme-text/30 uppercase tracking-[0.3em] mb-4 text-center">Color Lab</p>
        <div className="flex justify-between items-center gap-2">
          {THEMES.map((theme, i) => (
            <button
              key={theme.id}
              onClick={() => onThemeChange(i)}
              className={`w-9 h-9 rounded-full border-4 transition-all duration-300 ${
                currentThemeIdx === i ? 'border-theme-text scale-125 shadow-lg' : 'border-white'
              }`}
              style={{ backgroundColor: theme.main }}
            />
          ))}
        </div>
      </section>

      {/* 2. 倒數計時卡片 */}
      <section className="relative group perspective">
        <div className="bg-theme-main rounded-[56px] p-10 text-white shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] relative overflow-hidden border-2 border-white/20 theme-transition">
          <div className="relative z-10 flex flex-col items-center">
            <p className="text-[11px] font-black opacity-80 uppercase tracking-[0.6em] mb-6">Boarding Countdown</p>
            <div className="flex items-center gap-6">
              <div className="flex flex-col items-center">
                <h2 className="text-8xl font-black leading-none drop-shadow-2xl tracking-tighter">05</h2>
                <span className="text-[10px] font-black opacity-60 uppercase tracking-widest mt-2">Days</span>
              </div>
              <div className="h-20 w-px bg-white/20"></div>
              <div className="flex flex-col items-center">
                <h2 className="text-5xl font-black leading-none drop-shadow-2xl">12</h2>
                <span className="text-[10px] font-black opacity-60 uppercase tracking-widest mt-2">Hours</span>
              </div>
            </div>
          </div>
          <i className="fa-solid fa-paper-plane absolute -right-4 -bottom-4 text-[12rem] opacity-[0.1] rotate-[15deg]"></i>
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/10 to-transparent pointer-events-none"></div>
        </div>
      </section>

      {/* 3. 今日景點 幻燈片 */}
      <section className="space-y-6">
         <div className="flex items-center justify-between px-2">
            <h4 className="text-2xl font-black text-theme-text font-elegant tracking-tight">今日亮點動態</h4>
            <div className="flex gap-1.5">
              {highlights.map((_, i) => (
                <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${activeSlide === i ? 'w-6 bg-theme-main' : 'w-1.5 bg-theme-main/20'}`}></div>
              ))}
            </div>
         </div>
         
         <div className="relative h-[420px] rounded-[64px] overflow-hidden shadow-2xl group border-4 border-white">
            {highlights.map((h, i) => (
              <div 
                key={i} 
                className={`absolute inset-0 transition-all duration-1000 ease-out-expo ${activeSlide === i ? 'opacity-100 scale-100' : 'opacity-0 scale-110 pointer-events-none'}`}
              >
                <img src={h.img} className="w-full h-full object-cover" alt={h.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
                <div className="absolute bottom-10 left-10 right-10 text-white space-y-3">
                   <div className="flex items-center gap-3">
                      <span className="bg-theme-main px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">{h.time}</span>
                      <span className="text-white/60 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
                        <i className="fa-solid fa-location-dot"></i> {h.location}
                      </span>
                   </div>
                   <h5 className="text-4xl font-black leading-tight drop-shadow-md">{h.title}</h5>
                   <p className="text-sm font-bold opacity-70 leading-relaxed max-w-[80%]">{h.desc}</p>
                </div>
              </div>
            ))}
         </div>
      </section>

      {/* 4. 天氣動態小卡 */}
      <section className="bg-white rounded-[48px] p-8 border border-theme-main/10 shadow-[0_15px_40px_-10px_rgba(0,0,0,0.05)]">
        <div className="flex items-center justify-between mb-8">
           <div className="flex items-center gap-3">
             <div className="w-12 h-12 bg-theme-light rounded-[18px] flex items-center justify-center text-theme-main text-xl">
                <i className="fa-solid fa-cloud-sun"></i>
             </div>
             <div>
               <h4 className="text-lg font-black text-theme-text">東京 · 氣象動態</h4>
               <p className="text-[10px] font-black text-theme-text/30 uppercase tracking-widest">Weather Forecast</p>
             </div>
           </div>
           <span className="text-4xl font-black text-theme-text">24°</span>
        </div>
        <div className="flex gap-4 overflow-x-auto hide-scrollbar -mx-2 px-2">
           {[
             { time: '12:00', temp: '22°', icon: 'fa-sun' },
             { time: '15:00', temp: '24°', icon: 'fa-cloud-sun' },
             { time: '18:00', temp: '20°', icon: 'fa-cloud' },
             { time: '21:00', temp: '18°', icon: 'fa-moon' },
             { time: '00:00', temp: '16°', icon: 'fa-cloud-moon' },
           ].map((w, i) => (
             <div key={i} className="flex-shrink-0 bg-theme-light/30 px-6 py-5 rounded-[36px] text-center min-w-[95px] border border-theme-main/5 hover:border-theme-main/20 transition-all">
               <p className="text-[10px] text-theme-text/30 mb-3 font-black tracking-widest">{w.time}</p>
               <i className={`fa-solid ${w.icon} text-2xl mb-3 text-theme-main`}></i>
               <p className="text-lg font-black text-theme-text">{w.temp}</p>
             </div>
           ))}
        </div>
      </section>

      {/* 5. 匯率換算器 */}
      <section className="bg-white rounded-[56px] p-10 border border-theme-main/10 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.08)]">
         <div className="flex items-center gap-4 mb-10">
           <div className="w-12 h-12 bg-theme-main rounded-[20px] flex items-center justify-center text-white text-xl">
             <i className="fa-solid fa-calculator"></i>
           </div>
           <div>
             <h4 className="text-xl font-black text-theme-text tracking-tight">即時匯率換算</h4>
             <p className="text-[10px] font-black text-theme-text/30 uppercase tracking-widest">Real-time Exchange</p>
           </div>
         </div>
         <div className="space-y-6">
            <div className="flex items-center gap-6 bg-theme-light/40 p-7 rounded-[32px] border border-theme-main/5 group focus-within:border-theme-main/30 transition-all">
               <button 
                onClick={() => setCurrency(currency === 'JPY' ? 'KRW' : 'JPY')} 
                className="bg-theme-main text-white px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest active:scale-90 transition-all shadow-lg"
               >
                  {currency}
               </button>
               <input 
                 type="number" 
                 value={amountForeign} 
                 onChange={(e) => setAmountForeign(e.target.value)}
                 className="flex-1 bg-transparent text-3xl font-black text-theme-text outline-none placeholder:text-theme-text/20 tracking-tighter" 
                 placeholder="輸入外幣..."
               />
            </div>
            
            <div className="relative flex justify-center py-2">
               <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg border border-theme-main/10 text-theme-main relative z-10">
                  <i className="fa-solid fa-arrow-down-long"></i>
               </div>
               <div className="absolute top-1/2 left-0 w-full h-px bg-theme-main/10"></div>
            </div>

            <div className="bg-theme-main text-white p-8 rounded-[40px] shadow-2xl relative overflow-hidden group">
               <div className="flex items-center justify-between relative z-10">
                  <div>
                    <p className="text-[10px] font-black opacity-60 uppercase tracking-widest mb-2">估計支出 (TWD)</p>
                    <h5 className="text-5xl font-black tracking-tighter leading-none">NT$ {parseInt(convertedTWD).toLocaleString()}</h5>
                  </div>
                  <div className="text-right">
                    <p className="text-[9px] font-black opacity-40 uppercase tracking-widest">Rate Ref</p>
                    <p className="text-sm font-black mt-1">{exchangeRates[currency]}</p>
                  </div>
               </div>
               <i className="fa-solid fa-coins absolute -right-6 -bottom-6 text-[10rem] opacity-10 rotate-12 group-hover:scale-110 transition-transform duration-700"></i>
            </div>
         </div>
      </section>

      {/* 6. 旅人錦囊選單 */}
      <section className="grid grid-cols-3 gap-5">
        {[
          { id: 'vocab', icon: 'fa-language', label: '必備單字', color: 'bg-theme-main/10' },
          { id: 'emergency', icon: 'fa-life-ring', label: '緊急聯絡', color: 'bg-rose-500/10' },
          { id: 'culture', icon: 'fa-landmark', label: '注意事項', color: 'bg-indigo-500/10' },
        ].map((item) => (
          <button 
            key={item.id}
            onClick={() => setSubPage(item.id as any)}
            className="bg-white p-8 rounded-[48px] shadow-sm border border-theme-main/10 flex flex-col items-center gap-4 active:scale-95 transition-all group"
          >
            <div className={`w-14 h-14 ${item.color} rounded-[22px] flex items-center justify-center text-theme-main text-2xl group-hover:rotate-12 transition-transform`}>
              <i className={`fa-solid ${item.icon}`}></i>
            </div>
            <span className="text-[11px] font-black text-theme-text uppercase tracking-widest">{item.label}</span>
          </button>
        ))}
      </section>
    </div>
  );
};

export default HomeView;
