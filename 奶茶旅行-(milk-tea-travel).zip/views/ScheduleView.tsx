
import React, { useState, useMemo, useEffect } from 'react';
import { ScheduleItem, Category, TransportStep, GuideTips, Country } from '../types';
import { CATEGORY_COLORS, CATEGORY_ICONS } from '../constants';
import { db } from '../utils/firebase';
import { updateDoc, doc, onSnapshot, collection, query, orderBy, addDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { GoogleGenAI } from "@google/genai";

const ScheduleView: React.FC = () => {
  const [items, setItems] = useState<ScheduleItem[]>([]);
  const [selectedDate, setSelectedDate] = useState('2024-12-01');
  const [activeItem, setActiveItem] = useState<ScheduleItem | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showMapEdit, setShowMapEdit] = useState(false);
  const [tripMapUrl, setTripMapUrl] = useState<string>('');

  const [newItem, setNewItem] = useState({
    title: '',
    location: '',
    time: '10:00',
    category: 'attraction' as Category,
    country: 'Japan' as Country,
    notes: '',
    googleMapLink: '',
    naverMapLink: '',
  });

  useEffect(() => {
    const q = query(collection(db, "schedules"), orderBy("time", "asc"));
    const unsubSchedules = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ScheduleItem));
      setItems(data);
    });
    const unsubMap = onSnapshot(doc(db, "settings", "mapConfig"), (doc) => {
      if (doc.exists()) setTripMapUrl(doc.data().url || '');
    });
    return () => { unsubSchedules(); unsubMap(); };
  }, []);

  const filteredItems = useMemo(() => 
    items.filter(item => item.date === selectedDate),
  [items, selectedDate]);

  const dates = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date('2024-12-01');
      d.setDate(d.getDate() + i);
      return d.toISOString().split('T')[0];
    });
  }, []);

  const handleAddSchedule = async () => {
    if (!newItem.title) return;
    try {
      await addDoc(collection(db, "schedules"), {
        ...newItem,
        date: selectedDate,
        mapLinks: { google: newItem.googleMapLink, naver: newItem.naverMapLink },
        createdAt: serverTimestamp()
      });
      setShowAddModal(false);
      setNewItem({ ...newItem, title: '', location: '', googleMapLink: '', naverMapLink: '' });
    } catch (e) { console.error(e); }
  };

  const analyzeWithAI = async (item: ScheduleItem) => {
    setIsAnalyzing(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `你是一位資深專業導遊。請針對「${item.title}」（地點：${item.location}）提供攻略。
        請以 JSON 格式回傳，且務必包含交通路徑建議：
        { 
          "story": "景點背景故事", 
          "mustEat": ["必吃"], 
          "mustBuy": ["必買"], 
          "guideDuties": ["任務1:確認門票", "任務2:清點人數", "任務3:預約餐廳"],
          "transportTimeline": [
            { "type": "subway", "from": "當前位置", "to": "景點站", "line": "某某線", "duration": "20 min", "fromExit": "A1" }
          ]
        }`,
        config: { responseMimeType: "application/json" }
      });
      
      const text = response.text;
      if (text && item.id) {
        const result = JSON.parse(text);
        await updateDoc(doc(db, "schedules", item.id), { 
          guide: {
            story: result.story,
            mustEat: result.mustEat,
            mustBuy: result.mustBuy,
            guideDuties: result.guideDuties
          },
          transportTimeline: result.transportTimeline
        });
        setActiveItem({ ...item, guide: result, transportTimeline: result.transportTimeline });
      }
    } catch (e) { console.error(e); } finally { setIsAnalyzing(false); }
  };

  const pasteFromClipboard = async (type: 'google' | 'naver' | 'global') => {
    try {
      const text = await navigator.clipboard.readText();
      if (type === 'google') setNewItem({ ...newItem, googleMapLink: text });
      else if (type === 'naver') setNewItem({ ...newItem, naverMapLink: text });
      else if (type === 'global') {
        await setDoc(doc(db, "settings", "mapConfig"), { url: text });
        setTripMapUrl(text);
        setShowMapEdit(false);
      }
    } catch (err) { alert('請手動貼上連結'); }
  };

  return (
    <div className="space-y-6 pb-24 font-bold">
      {/* 標題與地圖總覽 (同前次實作) */}
      <div className="flex justify-center mb-4">
        <div className="bg-white/60 backdrop-blur-md px-6 py-2 rounded-full border border-theme-main/20 flex items-center gap-2 shadow-sm animate-bounce-slow">
          <span className="text-lg">🎄</span>
          <span className="text-sm font-black text-theme-text tracking-tighter">2025 美加聖誕節 & 跨年之旅</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
           <div className="flex items-center gap-2">
              <div className="w-1.5 h-6 bg-orange-400 rounded-full"></div>
              <i className="fa-solid fa-map-location-dot text-rose-400 text-lg"></i>
              <h3 className="text-xl font-black text-theme-text tracking-tight">地圖總覽</h3>
           </div>
           <button onClick={() => setShowMapEdit(true)} className="bg-theme-main/10 text-theme-main px-4 py-1.5 rounded-full text-xs font-black flex items-center gap-2 border border-theme-main/20 active:scale-95 transition-all"><i className="fa-solid fa-arrows-rotate"></i> 更換地圖</button>
        </div>
        <div className="relative h-80 w-full rounded-[48px] overflow-hidden shadow-xl border-4 border-white bg-slate-200">
          {tripMapUrl ? (
            <iframe src={tripMapUrl.includes('google.com/maps/d/') ? tripMapUrl.replace('/edit', '/embed') : tripMapUrl} className="w-full h-full border-0" allowFullScreen></iframe>
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-10 text-center">
               <i className="fa-solid fa-map text-5xl text-theme-text/10 mb-4"></i>
               <p className="text-xs text-theme-text/30 font-black">尚未設定地圖連結</p>
            </div>
          )}
        </div>
      </div>

      {/* 橫向日期選擇 */}
      <div className="flex gap-3 overflow-x-auto hide-scrollbar -mx-2 px-2 py-4">
        {dates.map(date => (
          <button key={date} onClick={() => setSelectedDate(date)} className={`flex flex-col items-center min-w-[75px] py-4 rounded-[32px] transition-all border-2 ${selectedDate === date ? 'bg-theme-main border-theme-main text-white shadow-lg scale-105' : 'bg-white border-theme-main/5 text-theme-text/40'}`}>
            <span className="text-[10px] font-black uppercase mb-1">{new Date(date).toLocaleDateString('zh-TW', { weekday: 'short' })}</span>
            <span className="text-xl font-black">{new Date(date).getDate()}</span>
          </button>
        ))}
      </div>

      {/* 行程列表 */}
      <div className="relative pl-10 space-y-10 before:content-[''] before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[3px] before:bg-theme-main/10">
        <button onClick={() => setShowAddModal(true)} className="absolute -left-1.5 -top-4 w-12 h-12 bg-theme-main rounded-full flex items-center justify-center text-white shadow-xl active:scale-90 transition-all z-20 border-4 border-white">
          <i className="fa-solid fa-plus text-lg"></i>
        </button>

        {filteredItems.map((item) => (
          <div key={item.id} className="relative group" onClick={() => setActiveItem(item)}>
            <div className="absolute -left-[30px] top-5 w-6 h-6 rounded-full border-4 border-white shadow-md z-10 bg-theme-main ring-8 ring-theme-main/5"></div>
            <div className="bg-white rounded-[44px] p-7 shadow-sm border border-theme-main/5 active:scale-[0.98] transition-all">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-black text-theme-text/20 uppercase tracking-widest">{item.time}</span>
                <span className={`px-4 py-1.5 rounded-full text-[10px] font-black border uppercase ${CATEGORY_COLORS[item.category]}`}>{item.category}</span>
              </div>
              <h4 className="font-black text-theme-text text-xl mb-2 tracking-tight">{item.title}</h4>
              <p className="text-[11px] font-black text-theme-text/40 flex items-center italic"><i className="fa-solid fa-location-dot mr-2 text-rose-400"></i> {item.location}</p>
            </div>
          </div>
        ))}
      </div>

      {/* 行程詳情 Modal - 領隊功能核心 */}
      {activeItem && (
        <div className="fixed inset-0 bg-theme-light z-[300] p-6 pt-16 overflow-y-auto animate-in slide-in-from-bottom duration-500 font-yuanwei">
           <div className="flex justify-between items-center mb-8">
              <button onClick={() => setActiveItem(null)} className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg"><i className="fa-solid fa-xmark"></i></button>
              <h3 className="text-lg font-black text-theme-text tracking-[0.2em] uppercase">Itinerary Expert</h3>
              <button onClick={() => analyzeWithAI(activeItem)} disabled={isAnalyzing} className={`w-14 h-14 bg-theme-main rounded-full flex items-center justify-center text-white shadow-xl ${isAnalyzing ? 'animate-pulse' : ''}`}>
                 {isAnalyzing ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-wand-magic-sparkles"></i>}
              </button>
           </div>
           
           <div className="space-y-6 max-w-sm mx-auto pb-10">
              <div className="bg-white p-10 rounded-[56px] shadow-sm border border-theme-main/10 text-center relative overflow-hidden">
                 <h2 className="text-3xl font-black text-theme-text mb-4 leading-tight">{activeItem.title}</h2>
                 <p className="text-xs font-black opacity-40"><i className="fa-solid fa-clock mr-2"></i> {activeItem.time} · {activeItem.location}</p>
              </div>

              {/* 領隊任務清單 */}
              {activeItem.guide?.guideDuties && (
                <div className="bg-theme-main/10 p-8 rounded-[48px] border border-theme-main/20">
                   <h5 className="text-[10px] font-black text-theme-main uppercase tracking-[0.3em] mb-6 flex items-center gap-2">
                     <i className="fa-solid fa-clipboard-check text-sm"></i> 領隊任務清單 (Guide Duties)
                   </h5>
                   <div className="space-y-4">
                      {activeItem.guide.guideDuties.map((duty, idx) => (
                        <div key={idx} className="flex items-center gap-4 bg-white/50 p-4 rounded-2xl border border-theme-main/5 active:scale-[0.98] transition-all">
                           <div className="w-6 h-6 rounded-full border-2 border-theme-main flex items-center justify-center bg-white">
                              <i className="fa-solid fa-check text-[10px] text-theme-main opacity-0 hover:opacity-100 transition-opacity"></i>
                           </div>
                           <span className="text-sm font-black text-theme-text/80">{duty}</span>
                        </div>
                      ))}
                   </div>
                </div>
              )}

              {/* 交通接駁細節 */}
              {activeItem.transportTimeline && activeItem.transportTimeline.length > 0 && (
                <div className="bg-white p-8 rounded-[48px] border border-theme-main/10 shadow-sm">
                   <h5 className="text-[10px] font-black text-theme-text/30 uppercase tracking-[0.3em] mb-6 flex items-center gap-2">
                     <i className="fa-solid fa-route text-sm text-theme-main"></i> 交通接駁路徑 (Transport)
                   </h5>
                   <div className="space-y-6 relative pl-6 before:content-[''] before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-theme-main/20">
                      {activeItem.transportTimeline.map((step, idx) => (
                        <div key={idx} className="relative">
                           <div className="absolute -left-[23px] top-1 w-4 h-4 rounded-full bg-theme-main border-2 border-white shadow-sm"></div>
                           <div className="space-y-1">
                              <p className="text-sm font-black text-theme-text">從 {step.from} {step.fromExit && <span className="text-[10px] text-theme-main bg-theme-main/5 px-2 py-0.5 rounded-full">{step.fromExit} 出口</span>}</p>
                              <div className="flex items-center gap-3 py-1">
                                 <i className={`fa-solid ${step.type === 'subway' ? 'fa-train-subway' : 'fa-person-walking'} text-theme-text/20`}></i>
                                 <span className="text-[10px] font-black text-theme-text/40">{step.line || '步行'} · 約 {step.duration}</span>
                              </div>
                              <p className="text-sm font-black text-theme-text/60">抵達 {step.to}</p>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              )}

              {/* 故事背景與美食 (同前次實作) */}
              {activeItem.guide?.story && (
                <div className="bg-white p-8 rounded-[48px] shadow-sm border border-theme-main/5">
                  <h5 className="text-[10px] font-black text-theme-main uppercase tracking-[0.3em] mb-4">景點故事</h5>
                  <p className="text-sm leading-relaxed text-theme-text/80 font-bold italic">"{activeItem.guide.story}"</p>
                </div>
              )}

              {/* 地圖跳轉按鈕 */}
              <div className="grid grid-cols-2 gap-4">
                 <a href={activeItem.mapLinks?.google || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(activeItem.location)}`} target="_blank" rel="noreferrer" className="bg-blue-600 text-white py-5 rounded-[32px] flex flex-col items-center gap-2 shadow-xl active:scale-95 transition-all"><i className="fa-brands fa-google"></i><span className="text-[9px] font-black uppercase">Google Map</span></a>
                 {activeItem.mapLinks?.naver && <a href={activeItem.mapLinks.naver} target="_blank" rel="noreferrer" className="bg-green-500 text-white py-5 rounded-[32px] flex flex-col items-center gap-2 shadow-xl active:scale-95 transition-all"><i className="fa-solid fa-compass"></i><span className="text-[9px] font-black uppercase">Naver Map</span></a>}
              </div>
           </div>
        </div>
      )}

      {/* 其他 Modal (更換地圖, 新增行程) 同前次實作 */}
      {showMapEdit && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[400] flex items-center justify-center p-6">
           <div className="w-full max-w-sm bg-theme-light rounded-[48px] p-10 shadow-2xl">
              <h3 className="text-2xl font-black text-theme-text mb-6">更換總覽地圖</h3>
              <div className="bg-white p-5 rounded-3xl border border-theme-main/10 mb-8 flex items-center gap-3">
                 <input type="text" placeholder="貼上 Google My Maps 連結..." className="flex-1 bg-transparent text-sm font-bold outline-none" id="globalMapInput"/>
                 <button onClick={() => pasteFromClipboard('global')} className="w-10 h-10 bg-theme-main/10 text-theme-main rounded-xl"><i className="fa-solid fa-paste"></i></button>
              </div>
              <button onClick={() => setShowMapEdit(false)} className="w-full py-4 bg-white rounded-2xl font-black text-theme-text/40">關閉</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default ScheduleView;
