
import React, { useState, useEffect } from 'react';
import { db } from '../utils/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';

interface Booking {
  id: string;
  type: 'flight' | 'hotel' | 'ticket' | 'car';
  title: string;
  details: any;
  isPrivate?: boolean;
}

const CategoryHeader: React.FC<{ title: string; icon: string }> = ({ title, icon }) => (
  <div className="flex items-center gap-3 mb-6 px-2 mt-8 first:mt-0">
    <div className="w-10 h-10 rounded-2xl bg-theme-main/15 flex items-center justify-center text-theme-main">
      <i className={`fa-solid ${icon} text-lg`}></i>
    </div>
    <h3 className="text-xl font-black text-theme-text tracking-widest">{title}</h3>
  </div>
);

const BookingsView: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    const q = query(collection(db, "bookings"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Booking));
      setBookings(data);
    });
    return () => unsubscribe();
  }, []);

  const FlightCard = ({ data }: { data: any }) => (
    <div className="bg-white rounded-[48px] shadow-xl overflow-hidden border-t-[12px] border-theme-main relative mb-6 animate-in slide-in-from-bottom duration-500">
      <div className="p-8 pb-6">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-plane text-theme-main"></i>
            <span className="text-[10px] font-black tracking-widest text-theme-text/40">{data.airline || 'JAL'}</span>
          </div>
          <span className="text-sm font-black text-theme-text">{data.flightNo}</span>
        </div>
        <div className="flex justify-between items-center">
          <div className="text-left">
            <h4 className="text-4xl font-black text-theme-text">{data.from}</h4>
            <p className="text-[10px] font-black text-theme-text/30 mt-1 uppercase">Taipei</p>
          </div>
          <div className="flex-1 px-4 flex flex-col items-center">
             <div className="w-full border-t-2 border-dashed border-theme-main/20 relative">
                <i className="fa-solid fa-plane absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-theme-main bg-white px-2"></i>
             </div>
          </div>
          <div className="text-right">
            <h4 className="text-4xl font-black text-theme-text">{data.to}</h4>
            <p className="text-[10px] font-black text-theme-text/30 mt-1 uppercase">Tokyo</p>
          </div>
        </div>
      </div>
      <div className="p-8 pt-6 bg-theme-light/30 grid grid-cols-3 gap-4 border-t border-dashed border-theme-main/10">
        <div><p className="text-[9px] font-black text-theme-text/30 mb-1">Gate</p><p className="text-sm font-black text-theme-text">{data.gate || '--'}</p></div>
        <div><p className="text-[9px] font-black text-theme-text/30 mb-1">Seat</p><p className="text-sm font-black text-theme-text">{data.seat || '--'}</p></div>
        <div><p className="text-[9px] font-black text-theme-text/30 mb-1">Time</p><p className="text-sm font-black text-theme-text">{data.time || '08:00'}</p></div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 pb-24">
      <CategoryHeader title="航班資訊" icon="fa-plane-up" />
      {bookings.filter(b => b.type === 'flight').length > 0 ? (
        bookings.filter(b => b.type === 'flight').map(b => <FlightCard key={b.id} data={b.details} />)
      ) : (
        <div className="p-8 text-center bg-white rounded-[40px] opacity-30 italic text-sm">尚未有航班資訊</div>
      )}

      <CategoryHeader title="住宿飯店" icon="fa-hotel" />
      {bookings.filter(b => b.type === 'hotel').length > 0 ? (
        bookings.filter(b => b.type === 'hotel').map(b => (
          <div key={b.id} className="bg-white rounded-[40px] p-8 shadow-sm border border-theme-main/5 mb-4 animate-in fade-in duration-500">
            <div className="flex justify-between items-start mb-4">
               <h4 className="text-xl font-black text-theme-text">{b.title}</h4>
               <span className="text-[10px] bg-theme-light px-3 py-1 rounded-full text-theme-main font-black uppercase">Stay</span>
            </div>
            <div className="space-y-4">
               <p className="text-sm text-theme-text/60 font-bold"><i className="fa-solid fa-location-dot mr-2 text-theme-main"></i>{b.details.address}</p>
               <div className="bg-theme-main/10 p-5 rounded-3xl border border-theme-main/5">
                  <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-1">Confirmation Code</p>
                  <p className="text-2xl font-black text-theme-text tracking-tighter">{b.details.confirmCode || 'N/A'}</p>
               </div>
            </div>
          </div>
        ))
      ) : (
        <div className="p-8 text-center bg-white rounded-[40px] opacity-30 italic text-sm">尚未有飯店資訊</div>
      )}
    </div>
  );
};

export default BookingsView;
