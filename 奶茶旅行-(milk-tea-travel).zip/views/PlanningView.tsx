
import React, { useState, useEffect, useMemo } from 'react';
import { TodoItem, Member } from '../types';
import { db } from '../utils/firebase';
import { collection, onSnapshot, query, updateDoc, doc, addDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';

const MOCK_MEMBERS: Member[] = [
  { id: 'all', name: '全體', avatar: 'https://cdn-icons-png.flaticon.com/512/921/921347.png', role: '全體成員' },
  { id: 'papa', name: '爸爸', avatar: 'https://i.pravatar.cc/150?u=papa', role: '團長' },
  { id: 'mama', name: '媽媽', avatar: 'https://i.pravatar.cc/150?u=mama', role: '採購' },
  { id: 'sister', name: '姊姊', avatar: 'https://i.pravatar.cc/150?u=sister', role: '翻譯' },
];

const SHOPPING_CATEGORIES = ["全部", "服飾/精品", "美食/特產", "保健/美妝", "溫哥華", "藥妝店"];
const PACKING_CATEGORIES = ["全部", "衣物", "電子產品", "藥品/衛生", "證件/錢包", "保養品", "其他"];

const PlanningView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'todo' | 'shopping' | 'packing'>('shopping');
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [selectedMemberId, setSelectedMemberId] = useState('all');
  const [filterTag, setFilterTag] = useState('全部');
  const [showAddModal, setShowAddModal] = useState(false);
  const [uploading, setUploading] = useState(false);

  // New Item State
  const [newItem, setNewItem] = useState({
    task: '',
    assignedTo: 'all',
    tags: [] as string[],
    address: '',
    note: '',
    imageUrl: '',
    packingCategory: '其他'
  });

  useEffect(() => {
    const q = query(collection(db, "todos"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TodoItem));
      setTodos(data);
    });
    return () => unsubscribe();
  }, []);

  const toggleTodo = async (id: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, "todos", id), { completed: !currentStatus });
    } catch (e) { console.error("更新失敗", e); }
  };

  const deleteItem = async (id: string) => {
    if (window.confirm("確定要刪除嗎？")) {
      await deleteDoc(doc(db, "todos", id));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewItem({ ...newItem, imageUrl: reader.result as string });
        setUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddItem = async () => {
    if (!newItem.task) return;
    try {
      await addDoc(collection(db, "todos"), {
        ...newItem,
        type: activeTab,
        completed: false,
        createdAt: serverTimestamp()
      });
      setShowAddModal(false);
      setNewItem({ task: '', assignedTo: 'all', tags: [], address: '', note: '', imageUrl: '', packingCategory: '其他' });
    } catch (e) { console.error(e); }
  };

  const filteredTodos = useMemo(() => {
    return todos.filter(t => {
      if (t.type !== activeTab) return false;
      const memberMatch = selectedMemberId === 'all' || t.assignedTo === selectedMemberId;
      const tagMatch = filterTag === '全部' || 
                       (t.tags && t.tags.includes(filterTag)) || 
                       (t.packingCategory === filterTag);
      return memberMatch && tagMatch;
    });
  }, [todos, activeTab, selectedMemberId, filterTag]);

  // 1. 必買清單渲染器 (視覺還原圖)
  const renderShoppingList = () => (
    <div className="space-y-6">
      <div className="flex gap-2 overflow-x-auto hide-scrollbar -mx-2 px-2 pb-2">
        {SHOPPING_CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setFilterTag(cat)}
            className={`px-4 py-2 rounded-full text-[10px] font-black whitespace-nowrap border transition-all ${filterTag === cat ? 'bg-theme-main text-white border-theme-main shadow-md' : 'bg-white text-theme-text/40 border-theme-main/10'}`}
          >
            {cat} <span className="opacity-40 ml-1">{todos.filter(t => t.type === 'shopping' && (cat === '全部' || t.tags?.includes(cat))).length}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        {filteredTodos.map(item => (
          <div key={item.id} className="bg-white rounded-[40px] overflow-hidden shadow-sm border border-theme-main/5 relative group animate-in zoom-in-95 duration-300">
            {/* 圖片區域 */}
            <div className="relative aspect-[4/5] bg-theme-light/50">
              <img src={item.imageUrl || `https://picsum.photos/seed/${item.id}/400/500`} alt={item.task} className="w-full h-full object-cover" />
              
              {/* Checkbox */}
              <button 
                onClick={(e) => { e.stopPropagation(); toggleTodo(item.id, item.completed); }}
                className={`absolute top-4 left-4 w-7 h-7 rounded-lg border-2 flex items-center justify-center transition-all ${item.completed ? 'bg-theme-main border-theme-main text-white' : 'bg-white/90 border-theme-main/20'}`}
              >
                {item.completed && <i className="fa-solid fa-check text-xs"></i>}
              </button>

              {/* 已購買標章印章 */}
              {item.completed && (
                <div className="absolute inset-0 bg-white/20 backdrop-blur-[1px] flex items-center justify-center">
                   <div className="bg-blue-500/90 text-white px-5 py-2 rounded-xl text-xs font-black rotate-[-15deg] shadow-lg border-2 border-white/40 tracking-widest">
                      ✓ 已購買
                   </div>
                </div>
              )}
            </div>

            {/* 內容文字區 */}
            <div className="p-5 space-y-2.5">
              <div className="flex flex-wrap gap-1.5">
                {item.tags?.map(tag => (
                  <span key={tag} className="bg-theme-main/5 text-theme-main text-[9px] px-2.5 py-1 rounded-full font-black border border-theme-main/10">{tag}</span>
                ))}
              </div>
              
              <h5 className="font-black text-base text-theme-text leading-tight">{item.task}</h5>
              
              <p className="text-[10px] text-theme-text/40 flex items-center italic">
                <i className="fa-solid fa-location-dot mr-1.5 text-rose-300"></i> 地點：{item.address || '當地超市'}
              </p>

              {item.note && (
                <div className="bg-theme-light/40 p-3 rounded-2xl border border-theme-main/5">
                  <p className="text-[10px] text-theme-text/60 leading-relaxed italic">
                    <i className="fa-solid fa-quote-left mr-1 opacity-20"></i> {item.note}
                  </p>
                </div>
              )}

              {/* 功能按鈕 */}
              <div className="flex gap-2 pt-2">
                <button className="flex-1 py-2 bg-theme-light text-theme-main text-[10px] font-black rounded-xl border border-theme-main/10 active:scale-95 transition-all">
                  <i className="fa-regular fa-pen-to-square mr-1"></i> 編輯
                </button>
                <button onClick={() => deleteItem(item.id)} className="flex-1 py-2 bg-rose-50 text-rose-400 text-[10px] font-black rounded-xl border border-rose-100 active:scale-95 transition-all">
                  <i className="fa-regular fa-trash-can mr-1"></i> 刪除
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // 2. 行李清單渲染器 (分類顯示)
  const renderPackingList = () => (
    <div className="space-y-6">
      <div className="flex gap-2 overflow-x-auto hide-scrollbar -mx-2 px-2 pb-2">
        {PACKING_CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setFilterTag(cat)}
            className={`px-4 py-2 rounded-full text-[10px] font-black whitespace-nowrap border transition-all ${filterTag === cat ? 'bg-theme-main text-white border-theme-main shadow-md' : 'bg-white text-theme-text/40 border-theme-main/10'}`}
          >
            {cat} <span className="opacity-40 ml-1">{todos.filter(t => t.type === 'packing' && (cat === '全部' || t.packingCategory === cat)).length}</span>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {filteredTodos.map(item => (
          <div 
            key={item.id} 
            onClick={() => toggleTodo(item.id, item.completed)}
            className={`bg-white rounded-[32px] p-6 flex items-center gap-5 border transition-all active:scale-[0.98] cursor-pointer ${item.completed ? 'opacity-40 border-transparent bg-theme-light/40' : 'border-white shadow-md'}`}
          >
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center border-2 transition-all ${item.completed ? 'bg-theme-main border-theme-main text-white shadow-inner' : 'border-theme-main/20 bg-theme-light'}`}>
              {item.completed && <i className="fa-solid fa-check text-xs"></i>}
            </div>
            <div className="flex-1">
              <p className={`text-lg font-black tracking-tight ${item.completed ? 'line-through text-theme-text/30' : 'text-theme-text'}`}>{item.task}</p>
              <div className="flex gap-2 mt-1">
                 <span className="text-[9px] font-black text-theme-main bg-theme-main/5 px-2.5 py-0.5 rounded-full uppercase tracking-widest">{item.packingCategory}</span>
                 <span className="text-[9px] font-black text-theme-text/30 uppercase tracking-widest">Assign: {item.assignedTo}</span>
              </div>
            </div>
            <button onClick={(e) => { e.stopPropagation(); deleteItem(item.id); }} className="text-theme-text/10 hover:text-rose-400 transition-colors p-3">
               <i className="fa-regular fa-trash-can"></i>
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-32 font-black">
      {/* 頂部切換與篩選器 */}
      <div className="flex justify-between items-center px-2">
        <h2 className="text-3xl font-black text-theme-text tracking-tight flex items-center gap-3">
          <span className="w-1.5 h-8 bg-theme-main rounded-full"></span>
          {activeTab === 'todo' ? '共同任務' : activeTab === 'shopping' ? '必買清單' : '行李清單'}
        </h2>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-theme-main text-white px-6 py-2.5 rounded-full text-[12px] font-black flex items-center gap-2 shadow-lg shadow-theme-main/20 active:scale-95 transition-all"
        >
          <i className="fa-solid fa-plus"></i> 新增
        </button>
      </div>

      <section className="bg-white rounded-[40px] p-6 shadow-sm border border-theme-main/5 flex gap-5 overflow-x-auto hide-scrollbar">
        {MOCK_MEMBERS.map(m => (
          <button 
            key={m.id} 
            onClick={() => setSelectedMemberId(m.id)}
            className="flex flex-col items-center gap-3 shrink-0 group"
          >
            <div className={`w-16 h-16 rounded-full p-1.5 transition-all ${selectedMemberId === m.id ? 'bg-theme-main shadow-xl scale-110' : 'bg-theme-light'}`}>
               <img src={m.avatar} alt={m.name} className="w-full h-full rounded-full border-2 border-white object-cover" />
            </div>
            <span className={`text-[11px] font-black ${selectedMemberId === m.id ? 'text-theme-main' : 'text-theme-text/30'}`}>{m.name}</span>
          </button>
        ))}
      </section>

      <div className="flex bg-white/60 backdrop-blur-xl p-2 rounded-[32px] border border-theme-main/10 shadow-inner">
        {['todo', 'packing', 'shopping'].map(t => (
          <button
            key={t}
            onClick={() => { setActiveTab(t as any); setFilterTag('全部'); }}
            className={`flex-1 py-4 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-300 ${activeTab === t ? 'bg-theme-main text-white shadow-xl scale-100' : 'text-theme-text/30'}`}
          >
            {t === 'todo' ? '任務' : t === 'packing' ? '行李' : '必買'}
          </button>
        ))}
      </div>

      <div className="px-1">
        {activeTab === 'shopping' ? renderShoppingList() : 
         activeTab === 'packing' ? renderPackingList() : (
           <div className="space-y-4">
             {filteredTodos.map(todo => (
               <div key={todo.id} onClick={() => toggleTodo(todo.id, todo.completed)} className={`bg-white rounded-[32px] p-6 flex items-center gap-5 border transition-all active:scale-[0.98] cursor-pointer ${todo.completed ? 'opacity-40 border-transparent bg-theme-light/40 shadow-none' : 'border-white shadow-md'}`}>
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center border-2 transition-all ${todo.completed ? 'bg-theme-main border-theme-main text-white shadow-inner' : 'border-theme-main/20 bg-theme-light'}`}>
                    {todo.completed && <i className="fa-solid fa-check text-xs"></i>}
                  </div>
                  <div className="flex-1">
                     <p className={`text-lg font-black tracking-tight ${todo.completed ? 'line-through text-theme-text/30' : 'text-theme-text'}`}>{todo.task}</p>
                     <p className="text-[10px] font-black text-theme-main opacity-40 uppercase tracking-widest mt-1">Assign: {todo.assignedTo}</p>
                  </div>
               </div>
             ))}
           </div>
         )}
      </div>

      {/* 新增 Modal (支援上傳照片) */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[500] flex items-end animate-in fade-in duration-300">
           <div className="w-full bg-theme-light rounded-t-[56px] p-10 pb-16 shadow-2xl animate-in slide-in-from-bottom duration-500 overflow-y-auto max-h-[92vh]">
              <div className="w-16 h-1.5 bg-theme-main/10 rounded-full mx-auto mb-8"></div>
              <h3 className="text-2xl font-black text-theme-text mb-8 text-center tracking-widest">新增到{activeTab === 'shopping' ? '必買清單' : '清單'}</h3>
              
              <div className="space-y-6">
                {/* 照片上傳區域 */}
                {activeTab === 'shopping' && (
                  <div className="relative aspect-video bg-white rounded-[32px] border-4 border-white shadow-inner overflow-hidden flex flex-col items-center justify-center group">
                    {newItem.imageUrl ? (
                      <img src={newItem.imageUrl} className="w-full h-full object-cover" alt="Preview" />
                    ) : (
                      <div className="text-center">
                        <i className={`fa-solid ${uploading ? 'fa-spinner fa-spin' : 'fa-camera'} text-4xl text-theme-main/20 mb-3`}></i>
                        <p className="text-[10px] font-black text-theme-text/30 uppercase tracking-widest">點擊上傳實體照</p>
                      </div>
                    )}
                    <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
                    {newItem.imageUrl && <div className="absolute top-4 right-4 bg-white/80 p-2 rounded-full text-rose-500" onClick={() => setNewItem({...newItem, imageUrl: ''})}><i className="fa-solid fa-xmark"></i></div>}
                  </div>
                )}

                <div className="bg-white p-7 rounded-[32px] border border-theme-main/5 shadow-inner">
                   <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">名稱 / 任務</p>
                   <input type="text" value={newItem.task} onChange={e => setNewItem({...newItem, task: e.target.value})} className="w-full bg-transparent text-xl font-black outline-none" placeholder="例如：Saje 精油護理油..." />
                </div>

                {activeTab === 'shopping' && (
                  <div className="grid grid-cols-1 gap-4">
                    <div className="bg-white p-7 rounded-[32px] border border-theme-main/5 shadow-inner">
                      <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">地點 (Address)</p>
                      <input type="text" value={newItem.address} onChange={e => setNewItem({...newItem, address: e.target.value})} className="w-full bg-transparent text-base font-bold outline-none" placeholder="例如：當地超市、Outlet..." />
                    </div>
                    <div className="bg-white p-7 rounded-[32px] border border-theme-main/5 shadow-inner">
                      <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">標籤 (以逗號分隔)</p>
                      <input type="text" placeholder="例如：保健/美妝, 溫哥華..." onChange={e => setNewItem({...newItem, tags: e.target.value.split(',').map(s => s.trim())})} className="w-full bg-transparent text-base font-bold outline-none" />
                    </div>
                  </div>
                )}

                {activeTab === 'packing' && (
                  <div className="bg-white p-7 rounded-[32px] border border-theme-main/5 shadow-inner">
                    <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">行李分類</p>
                    <select value={newItem.packingCategory} onChange={e => setNewItem({...newItem, packingCategory: e.target.value})} className="w-full bg-transparent font-black outline-none">
                      {PACKING_CATEGORIES.filter(c => c !== '全部').map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                )}

                <div className="bg-white p-7 rounded-[32px] border border-theme-main/5 shadow-inner">
                  <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">備註</p>
                  <textarea value={newItem.note} onChange={e => setNewItem({...newItem, note: e.target.value})} className="w-full bg-transparent font-bold outline-none min-h-[100px]" placeholder="備註規格、數量或其他注意事項..."></textarea>
                </div>

                <div className="flex gap-5">
                   <button onClick={() => setShowAddModal(false)} className="flex-1 py-6 bg-white rounded-[28px] font-black text-theme-text/30">取消</button>
                   <button onClick={handleAddItem} className="flex-1 py-6 bg-theme-main rounded-[28px] font-black text-white shadow-2xl shadow-theme-main/30 active:scale-95 transition-all">保存項目</button>
                </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default PlanningView;
