
import React, { useState, useEffect } from 'react';
import { Expense } from '../types';
import { db } from '../utils/firebase';
import { collection, onSnapshot, query, orderBy, addDoc, serverTimestamp } from 'firebase/firestore';

const CATEGORY_ICONS: Record<string, string> = {
  '美食': 'fa-bowl-food',
  '交通': 'fa-bus',
  '購物': 'fa-bag-shopping',
  '住宿': 'fa-bed',
  '其他': 'fa-ellipsis'
};

const CATEGORY_COLORS: Record<string, string> = {
  '美食': 'bg-rose-50 text-rose-500',
  '交通': 'bg-blue-50 text-blue-500',
  '購物': 'bg-amber-50 text-amber-500',
  '住宿': 'bg-indigo-50 text-indigo-500',
  '其他': 'bg-slate-50 text-slate-500'
};

const ExpenseView: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  
  // 新增支出 State
  const [newExp, setNewExp] = useState({
    description: '',
    amount: '',
    category: '美食',
    currency: 'JPY',
    paidBy: '我',
    date: new Date().toISOString().split('T')[0]
  });

  const JPY_TO_TWD = 0.215;

  useEffect(() => {
    const q = query(collection(db, "expenses"), orderBy("date", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Expense));
      setExpenses(data);
    });
    return () => unsubscribe();
  }, []);

  const handleAddExpense = async () => {
    if (!newExp.amount || !newExp.description) return;
    
    try {
      await addDoc(collection(db, "expenses"), {
        ...newExp,
        amount: parseFloat(newExp.amount),
        createdAt: serverTimestamp(),
      });
      setShowAddModal(false);
      setNewExp({ ...newExp, description: '', amount: '' });
    } catch (e) {
      console.error("新增失敗", e);
    }
  };

  const totalJPY = expenses
    .filter(e => e.currency === 'JPY')
    .reduce((sum, e) => sum + e.amount, 0);
  
  const grandTotalTWD = (totalJPY * JPY_TO_TWD) + expenses
    .filter(e => e.currency === 'TWD')
    .reduce((sum, e) => sum + e.amount, 0);

  const groupedExpenses = expenses.reduce((groups, exp) => {
    const date = exp.date;
    if (!groups[date]) groups[date] = [];
    groups[date].push(exp);
    return groups;
  }, {} as Record<string, Expense[]>);

  const sortedDates = Object.keys(groupedExpenses).sort((a, b) => b.localeCompare(a));

  return (
    <div className="space-y-8 pb-24">
      {/* 儀表板 */}
      <div className="bg-theme-main rounded-[56px] p-10 text-white shadow-xl relative overflow-hidden transition-all duration-700">
        <div className="relative z-10 text-center">
          <p className="text-[10px] font-black opacity-60 uppercase tracking-[0.4em] mb-4">Travel Budget Sync</p>
          <div className="space-y-1">
             <p className="text-[11px] font-black opacity-40 uppercase">Total in JPY</p>
             <h3 className="text-6xl font-black tracking-tighter">¥{totalJPY.toLocaleString()}</h3>
          </div>
          <div className="mt-8 pt-6 border-t border-white/20 flex justify-between">
             <div className="text-left">
                <p className="text-[9px] font-black opacity-40 uppercase">Est. Total TWD</p>
                <p className="text-xl font-black">NT$ {Math.round(grandTotalTWD).toLocaleString()}</p>
             </div>
             <div className="text-right">
                <p className="text-[9px] font-black opacity-40 uppercase">Rate Ref</p>
                <p className="text-xl font-black">{JPY_TO_TWD}</p>
             </div>
          </div>
        </div>
        <i className="fa-solid fa-coins absolute -right-6 -bottom-6 text-[12rem] opacity-10 rotate-12"></i>
      </div>

      {/* 列表標頭 */}
      <div className="flex justify-between items-center px-2">
        <h4 className="text-xl font-black text-theme-text tracking-widest">實時帳目</h4>
        <button 
          onClick={() => setShowAddModal(true)}
          className="w-14 h-14 bg-theme-main text-white rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-all"
        >
          <i className="fa-solid fa-plus text-xl"></i>
        </button>
      </div>

      {/* 帳目列表 */}
      <div className="space-y-10">
        {sortedDates.length > 0 ? sortedDates.map(date => (
          <div key={date} className="space-y-4">
             <div className="flex items-center gap-4 px-2">
                <span className="text-[10px] font-black text-theme-text/30 uppercase tracking-widest">{date}</span>
                <div className="flex-1 h-px bg-theme-main/10"></div>
             </div>
             {groupedExpenses[date].map(exp => (
               <div key={exp.id} className="bg-white rounded-[32px] p-6 flex items-center justify-between shadow-sm border border-theme-main/5 active:scale-[0.98] transition-all animate-in fade-in duration-500">
                  <div className="flex items-center gap-5">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl ${CATEGORY_COLORS[exp.category] || CATEGORY_COLORS['其他']}`}>
                      <i className={`fa-solid ${CATEGORY_ICONS[exp.category] || CATEGORY_ICONS['其他']}`}></i>
                    </div>
                    <div>
                      <h5 className="font-black text-theme-text">{exp.description}</h5>
                      <p className="text-[10px] font-black text-theme-text/30 uppercase tracking-widest mt-1">{exp.category} · {exp.paidBy}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-lg text-theme-text">
                      <span className="text-[10px] mr-1 opacity-30">{exp.currency}</span>
                      {exp.amount.toLocaleString()}
                    </p>
                  </div>
               </div>
             ))}
          </div>
        )) : (
          <div className="text-center py-20 opacity-30 italic font-black">點擊 + 號新增第一筆開銷</div>
        )}
      </div>

      {/* 新增支出 Modal (抽屜樣式) */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-end animate-in fade-in duration-300">
          <div className="w-full bg-theme-light rounded-t-[56px] p-10 pb-12 shadow-2xl animate-in slide-in-from-bottom duration-500">
            <div className="w-12 h-1.5 bg-theme-main/10 rounded-full mx-auto mb-8"></div>
            <div className="flex justify-between items-center mb-8">
               <h3 className="text-2xl font-black text-theme-text">新增帳目</h3>
               <button onClick={() => setShowAddModal(false)} className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-theme-text/20">
                 <i className="fa-solid fa-xmark"></i>
               </button>
            </div>
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-3xl border border-theme-main/5 shadow-inner">
                 <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-2">支出金額</p>
                 <div className="flex items-center gap-4">
                    <select 
                      value={newExp.currency} 
                      onChange={(e) => setNewExp({...newExp, currency: e.target.value})}
                      className="bg-theme-main/10 text-theme-main font-black py-2 px-3 rounded-xl outline-none"
                    >
                      <option value="JPY">JPY</option>
                      <option value="TWD">TWD</option>
                    </select>
                    <input 
                      type="number" 
                      inputMode="decimal"
                      value={newExp.amount}
                      onChange={(e) => setNewExp({...newExp, amount: e.target.value})}
                      placeholder="0.00"
                      className="flex-1 bg-transparent text-4xl font-black outline-none placeholder:opacity-10 tracking-tighter"
                    />
                 </div>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-theme-main/5 shadow-inner">
                 <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-2">消費項目</p>
                 <input 
                   type="text" 
                   value={newExp.description}
                   onChange={(e) => setNewExp({...newExp, description: e.target.value})}
                   placeholder="例如：一蘭拉麵..."
                   className="w-full bg-transparent text-xl font-bold outline-none placeholder:opacity-20"
                 />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-6 rounded-3xl border border-theme-main/5 shadow-inner">
                  <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">類別</p>
                  <select 
                    value={newExp.category}
                    onChange={(e) => setNewExp({...newExp, category: e.target.value})}
                    className="w-full bg-transparent font-bold outline-none"
                  >
                    {Object.keys(CATEGORY_ICONS).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-theme-main/5 shadow-inner">
                  <p className="text-[10px] font-black text-theme-main uppercase tracking-widest mb-3">付款人</p>
                  <select 
                    value={newExp.paidBy}
                    onChange={(e) => setNewExp({...newExp, paidBy: e.target.value})}
                    className="w-full bg-transparent font-bold outline-none"
                  >
                    <option value="我">我</option>
                    <option value="爸爸">爸爸</option>
                    <option value="媽媽">媽媽</option>
                    <option value="姊姊">姊姊</option>
                  </select>
                </div>
              </div>

              <button 
                onClick={handleAddExpense}
                className="w-full bg-theme-main py-6 rounded-3xl text-white font-black text-lg shadow-xl shadow-theme-main/20 active:scale-95 transition-all mt-4"
              >
                保存帳目
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseView;
