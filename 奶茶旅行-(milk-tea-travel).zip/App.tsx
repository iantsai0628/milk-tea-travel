
import React, { useState, useEffect } from 'react';
import { TabType } from './types';
import HomeView from './views/HomeView';
import ScheduleView from './views/ScheduleView';
import BookingsView from './views/BookingsView';
import ExpenseView from './views/ExpenseView';
import PlanningView from './views/PlanningView';
import MembersView from './views/MembersView';

export const THEMES = [
  { id: 'dan_hui', name: '淡灰', main: '#CDCDC6', light: '#F5F5F2', text: '#40403D' },
  { id: 'space_walk', name: '太空漫步', main: '#D2D8D6', light: '#F7F8F8', text: '#3E4241' },
  { id: 'cocoa', name: '可可蛋奶', main: '#F7F3E7', light: '#FFFEFB', text: '#4D473A' },
  { id: 'apricot', name: '杏子灰', main: '#EDF0E4', light: '#F9FAF7', text: '#42453B' },
  { id: 'damascus', name: '大馬士革', main: '#D6AD89', light: '#F9F4F0', text: '#47392D' },
  { id: 'blue_linen', name: '藍亞麻', main: '#CAD6E8', light: '#F6F8FB', text: '#313742' },
  { id: 'london_fog', name: '倫敦霧', main: '#A9B4AB', light: '#F1F3F1', text: '#343B35' },
  { id: 'grey_blue', name: '灰藍', main: '#76899A', light: '#F1F4F6', text: '#212B34' },
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [showSplash, setShowSplash] = useState(true);
  const [themeIdx, setThemeIdx] = useState(4); // 預設使用「大馬士革」

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const theme = THEMES[themeIdx];
    document.documentElement.style.setProperty('--theme-main', theme.main);
    document.documentElement.style.setProperty('--theme-light', theme.light);
    document.documentElement.style.setProperty('--theme-text', theme.text);
  }, [themeIdx]);

  if (showSplash) {
    return (
      <div className="fixed inset-0 bg-theme-light flex flex-col items-center justify-center z-50 animate-pulse transition-colors duration-700">
        <div className="w-24 h-24 bg-theme-main rounded-full flex items-center justify-center shadow-2xl mb-6 scale-110 transition-colors duration-700">
          <i className="fa-solid fa-mug-hot text-white text-4xl"></i>
        </div>
        <h1 className="text-3xl font-elegant text-theme-text tracking-[0.2em] font-black">奶茶旅行</h1>
        <p className="text-xs text-theme-main/60 mt-3 font-black uppercase tracking-[0.5em]">Milk Tea Travel</p>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <HomeView onThemeChange={(idx) => setThemeIdx(idx)} currentThemeIdx={themeIdx} />;
      case 'schedule': return <ScheduleView />;
      case 'bookings': return <BookingsView />;
      case 'expense': return <ExpenseView />;
      case 'planning': return <PlanningView />;
      case 'members': return <MembersView />;
      default: return <HomeView onThemeChange={setThemeIdx} currentThemeIdx={themeIdx} />;
    }
  };

  const navItems = [
    { id: 'home', icon: 'fa-house', label: '主頁' },
    { id: 'schedule', icon: 'fa-calendar-day', label: '行程' },
    { id: 'bookings', icon: 'fa-ticket', label: '預定' },
    { id: 'expense', icon: 'fa-wallet', label: '記帳' },
    { id: 'planning', icon: 'fa-suitcase', label: '準備' },
    { id: 'members', icon: 'fa-user-group', label: '成員' },
  ];

  return (
    <div className="min-h-screen pb-32 max-w-md mx-auto relative bg-theme-light shadow-2xl overflow-x-hidden font-yuanwei font-bold transition-colors duration-700">
      <header className="sticky top-0 bg-theme-light/80 backdrop-blur-xl z-30 px-6 py-6 flex justify-between items-center border-b border-theme-main/10">
        <h2 className="text-2xl font-black text-theme-text tracking-widest font-elegant">
          {navItems.find(n => n.id === activeTab)?.label}
        </h2>
        <div className="w-11 h-11 rounded-2xl bg-theme-main flex items-center justify-center text-white text-sm shadow-lg border-2 border-white/20 active:scale-90 transition-all cursor-pointer">
          <i className="fa-solid fa-user"></i>
        </div>
      </header>

      <main className="px-5 py-6">
        {renderContent()}
      </main>

      <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[92%] max-w-sm glass-light border border-white/40 shadow-[0_20px_50px_rgba(0,0,0,0.1)] rounded-[36px] p-3 z-40 flex justify-around items-center">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id as TabType)}
            className={`flex flex-col items-center justify-center w-13 h-13 rounded-2xl transition-all duration-500 active:scale-90 ${
              activeTab === item.id 
                ? 'bg-theme-main text-white shadow-xl scale-105' 
                : 'text-theme-text/30'
            }`}
          >
            <i className={`fa-solid ${item.icon} text-lg`}></i>
            <span className="text-[10px] mt-1.5 font-black uppercase tracking-tighter">
              {activeTab === item.id ? item.label : ''}
            </span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
