
import React from 'react';

export const CATEGORY_COLORS: Record<string, string> = {
  attraction: 'bg-orange-100 text-orange-700 border-orange-200',
  food: 'bg-rose-100 text-rose-700 border-rose-200',
  transport: 'bg-blue-100 text-blue-700 border-blue-200',
  hotel: 'bg-milktea-200 text-milktea-600 border-milktea-300',
};

export const CATEGORY_ICONS: Record<string, string> = {
  attraction: 'fa-camera-retro',
  food: 'fa-utensils',
  transport: 'fa-car-side',
  hotel: 'fa-bed',
};

export const CURRENCIES = ['TWD', 'JPY', 'USD', 'EUR', 'KRW'];
