
// Fix: Consolidating imports to resolve "no exported member" errors by separating type and value imports.
// In the Firebase modular SDK, interfaces like FirebaseApp and Auth are strictly types. 
// Importing them as values can cause compilation errors in some environments.
import { initializeApp, getApps } from 'firebase/app';
import type { FirebaseApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import type { Firestore } from 'firebase/firestore';
import { getAuth, signInAnonymously } from 'firebase/auth';
import type { Auth } from 'firebase/auth';

// 提示：請將您在 Firebase Console 複製的 Config 貼在下方對應位置
const firebaseConfig = {
  apiKey: "AIzaSyD4MAlo1N1SpqvldsRzmmr3dh2rrdgZhcc", 
  authDomain: "trip-45fa3.firebaseapp.com",
  projectId: "trip-45fa3",
  storageBucket: "trip-45fa3.firebasestorage.app",
  messagingSenderId: "375936620941",
  appId: "1:375936620941:web:e1f1516fa55e0e9a5585c4"
};

let app: FirebaseApp;
let db: Firestore;
let auth: Auth;

try {
  // Fix: Use getApps() to check for existing apps array to prevent "Firebase App already exists" error during hot-reloading
  const apps = getApps();
  app = apps.length ? (apps[0] as FirebaseApp) : initializeApp(firebaseConfig);
  db = getFirestore(app);
  auth = getAuth(app);
  
  // 啟動匿名登入，確保 Firestore 讀寫權限
  signInAnonymously(auth).catch((err: any) => {
    console.error("Firebase Auth Error:", err.message);
  });
} catch (e) {
  console.warn("Firebase 初始化失敗:", e);
}

export { db, auth };
