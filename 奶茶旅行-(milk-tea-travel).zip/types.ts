
export type TabType = 'home' | 'schedule' | 'bookings' | 'expense' | 'planning' | 'members';

export type Category = 'attraction' | 'food' | 'transport' | 'hotel';
export type Country = 'Japan' | 'Korea';

export interface TransportStep {
  type: 'walking' | 'subway' | 'bus' | 'taxi' | 'train';
  line?: string;
  direction?: string; // e.g., "新宿方向"
  from: string;
  fromExit?: string; // e.g., "A3 出口"
  to: string;
  toExit?: string;
  duration: string;
  stopsCount?: number; // 經過幾站
  stationInfo?: string;
}

export interface MapLinks {
  google?: string;
  naver?: string;
}

export interface GuideTips {
  mustEat?: string[];
  mustOrder?: string[];
  mustBuy?: string[];
  bookingCode?: string;
  story?: string;
  tips?: string[];
  guideDuties?: string[]; // 導遊專屬職責清單
}

export interface ScheduleItem {
  id: string;
  time: string;
  title: string;
  location: string;
  category: Category;
  country: Country;
  notes?: string;
  imageUrl?: string;
  date: string;
  mapLinks: MapLinks;
  lat?: number;
  lng?: number;
  guide?: GuideTips;
  transportTimeline?: TransportStep[];
}

export interface Expense {
  id: string;
  amount: number;
  currency: string;
  category: string;
  paidBy: string;
  splitWith: string[];
  date: string;
  description: string;
}

export interface TodoItem {
  id: string;
  task: string;
  completed: boolean;
  assignedTo: string;
  type: 'todo' | 'packing' | 'shopping';
  packingCategory?: string;
  // Shopping Specifics
  imageUrl?: string;
  tags?: string[];
  address?: string;
  note?: string;
}

export interface Member {
  id: string;
  name: string;
  avatar: string;
  role: string;
}
